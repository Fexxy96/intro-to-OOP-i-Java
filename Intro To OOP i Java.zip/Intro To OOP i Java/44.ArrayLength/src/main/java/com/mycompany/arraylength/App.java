/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.arraylength;

/**
 *
 * @author Dell-User
 */
public class App {

    public static void main(String[] args) {
        String[]cars = {"Volvo","BMW", "Ford", "Mazda"};
        System.out.println(cars.length);
        //Outputs 4
    }
}
