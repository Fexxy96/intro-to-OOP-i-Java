/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javacontinue;

/**
 *
 * @author Dell-User
 */
public class App {

    public static void main(String[] args) {
        for (int i = 0; i < 10; i++){
            if ( i == 4) {
                continue;
            }
            System.out.println(i);
            }
        }
}
