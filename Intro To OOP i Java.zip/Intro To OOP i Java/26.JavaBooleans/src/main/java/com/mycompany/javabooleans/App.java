/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javabooleans;

/**
 *
 * @author Dell-User
 */
public class App {

    public static void main(String[] args) {
      int x = 10;
      int y = 9;
      System.out.println(x>y); //returns true because 10 is higher than 9
    }
}
