/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javamulti.linecomments;

/**
 *
 * @author Dell-User
 */
public class App {

    public static void main(String[] args) {
        /* The code below will print the words Hello world
        to the sreccn' and it is amazing*/
        
        System.out.println("Hello World!");
    }
}
