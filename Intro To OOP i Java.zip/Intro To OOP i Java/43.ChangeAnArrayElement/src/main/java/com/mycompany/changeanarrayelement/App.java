/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.changeanarrayelement;

/**
 *
 * @author Dell-User
 */
public class App {

    public static void main(String[] args) {
        String[]cars = {"Volvo", "BMW","Ford", "Mazda"};
        cars[0] = "Opel";
        System.out.println(cars[0]);
        //Now outputs OIpel Insted of Volvo
    }
}
