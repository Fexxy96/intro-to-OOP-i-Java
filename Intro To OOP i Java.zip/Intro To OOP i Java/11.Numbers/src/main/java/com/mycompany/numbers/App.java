/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.numbers;

/**
 *
 * @author Dell-User
 */
public class App {

    public static void main(String[] args) {
        byte myNum = 100;
        System.out.println(myNum);
        
      
       
       
    }
}
