/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.parametersandarguments;

/**
 *
 * @author Dell-User
 */
public class Main {

    static void myMethod(String fname) {
        System.out.println(fname + "Refnes");
    }
    Public static void main(String [] args) {
        myMethod("Liam");
        myMethod("jenny");
        myMethod("Anja");
    }
    }
// Liam Refnes
//Jenny Refnes
//Anja refnes