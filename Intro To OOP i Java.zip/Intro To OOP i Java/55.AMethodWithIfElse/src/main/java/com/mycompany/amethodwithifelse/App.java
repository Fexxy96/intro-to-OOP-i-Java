/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.amethodwithifelse;

/**
 *
 * @author Dell-User
 */
public class App {
    //create a checkAge() method with an ineger varaible called age
    static void checkAge(int Age) {
        
        //if agae is less than 18, print "access denied"
        if (Age < 18) {
            System.out.println("access denied. You are not old enough");
            
            // if age is greater than, or equal to, 18, print "access granted"
        }else{
            System.out.println("access granted. You are old enough");
        }
    }

    public static void main(String[] args) {
       checkAge(20); //call the checkAge method and pass along an age 20
    }
}

//Outputs "Access granted. You are old enough"