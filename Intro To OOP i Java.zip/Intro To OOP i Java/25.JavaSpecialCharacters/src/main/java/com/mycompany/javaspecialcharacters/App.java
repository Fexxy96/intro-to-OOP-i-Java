/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javaspecialcharacters;

/**
 *
 * @author Dell-User
 */
public class App {

    public static void main(String[] args) {
        String txt = "We are the so called \"vikings\" from the North";
       
    }
}
