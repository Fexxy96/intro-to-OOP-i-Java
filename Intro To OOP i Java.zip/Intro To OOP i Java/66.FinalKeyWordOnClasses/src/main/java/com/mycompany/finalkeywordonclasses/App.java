/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.finalkeywordonclasses;

import com.sun.tools.javac.Main;

/**
 *
 * @author Dell-User
 */
public class App{
    final int x = 10;

    public static void main(String[] args) {
        Main myObj = new Main();
        myObj.x =25; // will generate error:cannot assigna value to a final variable
        System.out.println(myObj.x);
    }
}
