/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javacharacters;

/**
 *
 * @author Dell-User
 */
public class App {

    public static void main(String[] args) {
        char myGrade ='8';
        System.out.println(myGrade);
        
        String greeting = " Hello World";
        System.out.println(greeting);
    }
}
