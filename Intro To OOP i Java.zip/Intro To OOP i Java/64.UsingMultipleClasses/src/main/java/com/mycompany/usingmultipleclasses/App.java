/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.usingmultipleclasses;

/**
 *
 * @author Dell-User
 */
public class App {

    public static void main(String[] args) {
       NewClass myobj = NewClass();
       System.out.println(myobj.y);
    }

    private static NewClass NewClass() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
