/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javaidentifiers;

/**
 *
 * @author Dell-User
 */
public class App {

    public static void main(String[] args) {
//Good
        //ok, but not so easy to understand what m actually is

    }
}
