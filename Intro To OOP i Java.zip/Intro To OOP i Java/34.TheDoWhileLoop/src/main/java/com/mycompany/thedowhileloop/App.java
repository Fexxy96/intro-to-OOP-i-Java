/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.thedowhileloop;

/**
 *
 * @author Dell-User
 */
public class App {

    public static void main(String[] args) {
        int i = 0;
        do {
            System.out.println(i);
            i++;
        } 
        while (i < 5);
        }
    }

