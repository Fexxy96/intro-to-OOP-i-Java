/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ifstatement2;

/**
 *
 * @author Dell-User
 */
public class App {

    public static void main(String[] args) {
        int x = 20;
        int y = 18;
        if (x>y){
            System.out.println(" x is greater than y ");
        }
                
    }
}
