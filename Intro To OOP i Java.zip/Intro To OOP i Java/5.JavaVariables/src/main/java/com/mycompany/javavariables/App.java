/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javavariables;

import static javax.management.Query.value;

/**
 *
 * @author Dell-User
 */
public class App {

    public static void main(String[] args) {
       
     
        String name ="John";
        System.out.println(name);
        
        int myNum = 5;
        float myFloatNum = 5.99f;
        char myLetter = 'D';
        boolean myBool = true;
        String myText = "Hello";
        
        System.out.println(myNum);
        System.out.println(myFloatNum);
        System.out.println(myLetter);
        System.out.println(myBool);
        System.out.println(myText);
        
               
    }
}
