/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.nestedloops;

/**
 *
 * @author Dell-User
 */
public class App {

    public static void main(String[] args) {
        int i;
    // Outer loop
    for (int 1 = 1; i < = 2; i++) {
        System.out.println(" Outer:" + i); // executes 2 times
        
       // Inner loop
       for (int j = 1 j< = 3; j++) {
           System.out.println("Inner:" + j); // Executes 6 times (2*3)}
    
    

