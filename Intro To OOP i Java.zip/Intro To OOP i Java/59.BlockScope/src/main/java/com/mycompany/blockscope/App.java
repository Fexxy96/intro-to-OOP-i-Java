/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.blockscope;

/**
 *
 * @author Dell-User
 */
public class App {

    public static void main(String[] args) {
        //code here CANNOT use x
        
        {//this is a block
            // code here CANNOT use x
            
            int x = 100;
            
            //code here CAN use x
        System.out.println(x);
        
        }//the block ends here
        
        //code here CANNOT use x
    }
}
