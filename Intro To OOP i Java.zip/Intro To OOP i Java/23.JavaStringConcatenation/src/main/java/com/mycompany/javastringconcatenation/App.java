/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javastringconcatenation;

/**
 *
 * @author Dell-User
 */
public class App {

    public static void main(String[] args) {
       String firstName = "John";
       String lastName = "Doe";
       System.out.println(firstName + "" + lastName);
    }
}
