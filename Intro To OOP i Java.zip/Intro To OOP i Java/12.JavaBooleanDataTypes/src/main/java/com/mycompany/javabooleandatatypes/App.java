/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javabooleandatatypes;

/**
 *
 * @author Dell-User
 */
public class App {

    public static void main(String[] args) {
        boolean IsJavaFun = true;
        System.out.println(IsJavaFun);// ouputs true
        boolean IsFishTasty = false;
        System.out.println(IsFishTasty); // outputs false
        
    } 
}
