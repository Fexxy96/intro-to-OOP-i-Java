/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.loopthroughanarray;

/**
 *
 * @author Dell-User
 */
public class App {

    public static void main(String[] args) {
        String[] cars= {"Volvo","BMW","Ford", "Mazda"};
        for (int i = 0; i< cars.length; i++) {
            System.out.println(cars[i]);
        }
    }
}
