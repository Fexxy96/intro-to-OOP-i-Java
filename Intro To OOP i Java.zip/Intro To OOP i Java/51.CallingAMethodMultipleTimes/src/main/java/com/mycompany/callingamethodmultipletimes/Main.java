/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.callingamethodmultipletimes;

/**
 *
 * @author Dell-User
 */
public class Main{

 static void myMethood() {
        System.out.println("I just got executed");
    } 
    }
public static void main (String[]args){
myMethod();
myMethod();
myMethod();
 }
}

// i just got executed
// i just got executed
// i just got executed
