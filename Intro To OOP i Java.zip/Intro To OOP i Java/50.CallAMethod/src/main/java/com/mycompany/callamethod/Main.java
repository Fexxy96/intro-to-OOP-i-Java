/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.callamethod;

/**
 *
 * @author Dell-User
 */
public class Main {

     static void myMethod() {
        System.out.println("I just got executed");
    }
    public static void main (String[]args) {
        myMethod();
    }
}
//Outputs " I just got executed"
