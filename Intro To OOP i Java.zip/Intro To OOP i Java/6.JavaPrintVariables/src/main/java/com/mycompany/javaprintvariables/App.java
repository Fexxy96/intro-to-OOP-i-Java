/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javaprintvariables;

/**
 *
 * @author Dell-User
 */
public class App {

    public static void main(String[] args) {
       String name = "John";
       System.out.println("Hello" + name);
       
       String firstName = "John";
        String lastName = "Doe";
       String fullName = firstName + lastName;
       System.out.println(fullName);
    }
}
