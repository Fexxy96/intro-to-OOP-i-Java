/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javatypecasting;

/**
 *
 * @author Dell-User
 */
public class App {

    public static void main(String[] args) {
        int myInt = 9;
        double myDouble = myInt; //Automatic casting int to double
        
        System.out.println(myInt); //outputs 9
        System.out.println(myDouble); //outputs 9.0
                
    }
}
