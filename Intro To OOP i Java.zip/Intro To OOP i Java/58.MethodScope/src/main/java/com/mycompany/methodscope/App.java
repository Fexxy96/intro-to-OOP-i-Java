/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.methodscope;

/**
 *
 * @author Dell-User
 */
public class App {

    public static void main(String[] args) {
        //code here CANNOT use x
        
        int x = 100;
                
                //code here can use x
        System.out.println(x);
    }
}
