/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javaifelse;

/**
 *
 * @author Dell-User
 */
public class App {

    public static void main(String[] args) {
        if (20> 18){
            System.out.println(" 20 is greater than 18");
        }
        int time = 20;
        if (time < 18) {
            System.out.println("Goodday.");
        }else{
            System.out.println("Good evening.");
        }
                
        }
    }

