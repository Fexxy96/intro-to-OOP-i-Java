/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.accessmethodswithanobject;

/**
 *
 * @author Dell-User
 */
//create a main class
public class Main{

    //create a fullThrottle() method
    public void fullThrottle();{
    System.out.println("the car is going as full as it can!");
}

//ccreate a speed() method and a parameter
    public static void speed(int maxSpeed) {
        System.out.println("Max speed is:" + maxSpeed);
    }
    //inside main, call the methods on the mycar objects
    public static void main(String[]args){
        Main mycar = new Main(); // create a myCar object
       myCar.fullThrottle(); //call the fullThrottle()method
       myCar.speed(200); // call the speed() method
            }
}
