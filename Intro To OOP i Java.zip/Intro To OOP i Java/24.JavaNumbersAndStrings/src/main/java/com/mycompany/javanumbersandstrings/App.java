/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javanumbersandstrings;

/**
 *
 * @author Dell-User
 */
public class App {

    public static void main(String[] args) {
        int x = 10;
        int y = 20;
        int z = x + y;
        System.out.println(z);
        
        String a = "10";
        String b = "20";
        String c = a + b;
        System.out.println(c);
        
        String i = "10";
        int j = 20;
        String k = i+ j;
        System.out.println(k);
    }
}
