/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.createaclass;

/**
 *
 * @author Dell-User
 */
public class App {
int x = 5;
    public static void main(String[] args) {
        App myObj = new App();
        System.out.println(myObj.x);
        
    }
}
