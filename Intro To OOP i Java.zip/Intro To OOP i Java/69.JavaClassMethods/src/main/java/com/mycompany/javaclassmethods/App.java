/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javaclassmethods;

/**
 *
 * @author Dell-User
 */
public class App {
static void myMethod(){
    
        System.out.println("Hello World!");
    }
}
