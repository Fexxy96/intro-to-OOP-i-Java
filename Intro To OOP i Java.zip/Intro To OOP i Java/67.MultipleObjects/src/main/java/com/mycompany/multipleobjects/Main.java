/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.multipleobjects;

/**
 *
 * @author Dell-User
 */
public class Main {
    int x = 5;

    public static void main(String[] args) {
        Main myObj1 = new Main(); //object 1
        Main myObj2 = new Main(); //object 2
        myObj2.x = 25;
        System.out.println(myObj1.x); // outputs 5
        System.out.println(myObj2.x); // outputs 25
    }
}
