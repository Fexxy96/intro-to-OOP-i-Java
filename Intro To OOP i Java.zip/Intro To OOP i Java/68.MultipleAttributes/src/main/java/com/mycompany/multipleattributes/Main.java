/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.multipleattributes;

/**
 *
 * @author Dell-User
 */
public class Main{
    String fname = "John";
    String lname;
    int age = 24;

    public static void main(String[] args) {
        Main myObj = new Main();
         System.out.println("Name:" + myObj.fname + myObj.lname);
          System.out.println("Age:" + myObj.age);
    }

    public Main() {
        this.lname = "Doe";
    }
}
