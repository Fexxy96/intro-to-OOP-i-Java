/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.returnvalues;

/**
 *
 * @author Dell-User
 */
public class App {
    static int myMethod(int x){
        return 5 + x;
    }

    public static void main(String[] args) {
        System.out.println(myMethod (3));
    }
}
//outputs 8(5+3)