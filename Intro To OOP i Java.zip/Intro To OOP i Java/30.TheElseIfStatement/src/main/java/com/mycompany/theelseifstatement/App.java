/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.theelseifstatement;

/**
 *
 * @author Dell-User
 */
public class App {

    public static void main(String[] args) {
       int time = 22;
               if (time<10) {
                   System.out.println("Good morning.");
               }else if (time <18) {
                   System.out.println("Goodday");
               } else {
                   System.out.println(" Good evening");
               } 
               
               //outputs "good evening"
               }
    }

