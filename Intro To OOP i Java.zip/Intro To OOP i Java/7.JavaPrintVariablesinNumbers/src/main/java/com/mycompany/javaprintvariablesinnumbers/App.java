/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javaprintvariablesinnumbers;

/**
 *
 * @author Dell-User
 */
public class App {

    public static void main(String[] args) {
        int x = 5;
        int y = 6;
        System.out.println(x + y); // Print the value of x+ y
    }
}
